import os
import logging
import urllib.parse
from flask import Flask, render_template, request, jsonify, abort

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "my_fallback_secret")

# Default HLS stream URL (always use HTTPS for secure connections)
DEFAULT_STREAM_URL = "https://13.124.71.203/hls/playlist.m3u8"

@app.route('/')
def index():
    """Render the main video player page."""
    # Allow custom stream URL to be passed as a query parameter (for testing purposes)
    stream_url = request.args.get('stream_url', DEFAULT_STREAM_URL)
    
    # Validate URL
    if not stream_url.startswith(('http://', 'https://')):
        logging.warning(f"Invalid stream URL format: {stream_url}")
        return render_template('index.html', 
                              stream_url=DEFAULT_STREAM_URL, 
                              error="Invalid stream URL format. Using default stream.")
    
    return render_template('index.html', stream_url=stream_url)

@app.route('/embed')
def embed():
    """Render the embed player page for iframe usage."""
    stream_url = request.args.get('stream_url')
    
    # If no stream URL provided or invalid format, show error
    if not stream_url:
        logging.warning("No stream URL provided for embed")
        return render_template('embed.html', error="No stream URL provided")
    
    # Validate URL format
    if not stream_url.startswith(('http://', 'https://')):
        logging.warning(f"Invalid stream URL format for embed: {stream_url}")
        return render_template('embed.html', error="Invalid stream URL format")
    
    return render_template('embed.html', stream_url=stream_url)

@app.route('/api/stream-info')
def stream_info():
    """API endpoint to get information about the stream."""
    stream_url = request.args.get('stream_url', DEFAULT_STREAM_URL)
    
    # In a production app, you might fetch metadata about the stream here
    # For now, we'll return basic info
    stream_info = {
        "url": stream_url,
        "provider": "HWO Security",
        "format": "HLS",
        "is_live": True,
        "supports_mobile": True
    }
    
    return jsonify(stream_info)

@app.route('/health')
def health_check():
    """Simple health check endpoint."""
    return jsonify({"status": "ok"})

# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('index.html', error="Page not found"), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('index.html', error="Internal server error"), 500
