document.addEventListener('DOMContentLoaded', function() {
    // Check browser capabilities
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
    const isAndroid = /Android/.test(navigator.userAgent);
    
    // Configure player options based on device
    const playerOptions = {
        html5: {
            hls: {
                overrideNative: !isIOS, // Use native HLS on iOS
                enableLowInitialPlaylist: true,
                limitRenditionByPlayerDimensions: true,
                smoothQualityChange: true
            },
            nativeVideoTracks: isIOS,
            nativeAudioTracks: isIOS,
            nativeTextTracks: isIOS
        },
        fluid: true,
        controls: true,
        autoplay: false,
        preload: isMobile ? 'metadata' : 'auto', // Reduce data usage on mobile
        playbackRates: [0.5, 1, 1.5, 2],
        responsive: true,
        liveui: true,
        inactivityTimeout: 3000, // Hide controls after 3 seconds of inactivity
        controlBar: {
            progressControl: {
                seekBar: {
                    seekableDisplay: true
                }
            }
        }
    };

    // Initialize video.js player
    const player = videojs('hls-video', playerOptions);

    // Handle player errors with better error messages
    player.on('error', function() {
        console.error('Video player error:', player.error());
        
        // Get the error message and code
        const errorCode = player.error().code;
        let errorMsg = player.error().message || 'Unknown error occurred';
        
        // Provide more user-friendly error messages
        switch(errorCode) {
            case 1: // MEDIA_ERR_ABORTED
                errorMsg = 'The video playback was aborted.';
                break;
            case 2: // MEDIA_ERR_NETWORK
                errorMsg = 'A network error occurred. Please check your connection and try again.';
                break;
            case 3: // MEDIA_ERR_DECODE
                errorMsg = 'The video playback was interrupted. This is often caused by corruption or unsupported features.';
                break;
            case 4: // MEDIA_ERR_SRC_NOT_SUPPORTED
                errorMsg = 'The video format is not supported by your browser or the server refused the connection.';
                break;
            case 5: // MEDIA_ERR_ENCRYPTED
                errorMsg = 'The video is encrypted and we do not have the keys to decrypt it.';
                break;
        }
        
        // Create a styled error message element
        const errorElement = document.createElement('div');
        errorElement.className = 'alert alert-danger mt-3';
        errorElement.innerHTML = `
            <div class="d-flex align-items-center">
                <i class="fas fa-exclamation-triangle me-3 fs-4"></i>
                <div>
                    <strong>Error: </strong> ${errorMsg}
                    <div class="small text-secondary mt-1">Error code: ${errorCode}</div>
                </div>
            </div>
        `;
        
        // Insert after video container
        const videoContainer = document.querySelector('.video-container');
        videoContainer.parentNode.insertBefore(errorElement, videoContainer.nextSibling);
    });

    // Initialize UI elements
    const playBtn = document.getElementById('play-btn');
    const pauseBtn = document.getElementById('pause-btn');
    const muteBtn = document.getElementById('mute-btn');
    const fullscreenBtn = document.getElementById('fullscreen-btn');
    const volumeSlider = document.getElementById('volume-slider');
    const volumeValue = document.getElementById('volume-value');
    const currentTimeEl = document.getElementById('current-time');
    const durationEl = document.getElementById('duration');
    const capturePreviewBtn = document.getElementById('capture-preview');
    const previewImage = document.getElementById('preview-image');
    const noPreview = document.getElementById('no-preview');

    // Button States - Function to update UI based on player state
    function updateButtonStates() {
        if (player.paused()) {
            playBtn.classList.add('btn-info');
            playBtn.classList.remove('btn-secondary');
            pauseBtn.classList.add('btn-secondary');
            pauseBtn.classList.remove('btn-info');
        } else {
            pauseBtn.classList.add('btn-info');
            pauseBtn.classList.remove('btn-secondary');
            playBtn.classList.add('btn-secondary');
            playBtn.classList.remove('btn-info');
        }
        
        if (player.muted()) {
            muteBtn.innerHTML = '<i class="fas fa-volume-up me-1"></i> Unmute';
        } else {
            muteBtn.innerHTML = '<i class="fas fa-volume-mute me-1"></i> Mute';
        }
    }

    // Play button functionality
    playBtn.addEventListener('click', function() {
        player.play().catch(error => {
            console.error('Play error:', error);
            // If autoplay is prevented (common on mobile), show a message
            if (error.name === 'NotAllowedError') {
                const errorElement = document.createElement('div');
                errorElement.className = 'alert alert-warning mt-3 alert-dismissible fade show';
                errorElement.innerHTML = `
                    <i class="fas fa-exclamation-circle me-2"></i>
                    Autoplay is prevented by your browser. Please tap the play button on the video to start playback.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                `;
                const videoContainer = document.querySelector('.video-container');
                videoContainer.parentNode.insertBefore(errorElement, videoContainer.nextSibling);
            }
        });
        updateButtonStates();
    });

    // Pause button functionality
    pauseBtn.addEventListener('click', function() {
        player.pause();
        updateButtonStates();
    });

    // Mute button functionality with improved state handling
    muteBtn.addEventListener('click', function() {
        player.muted(!player.muted());
        updateButtonStates();
    });

    // Fullscreen button functionality with fallbacks for different browsers
    fullscreenBtn.addEventListener('click', function() {
        if (player.isFullscreen()) {
            player.exitFullscreen();
        } else {
            player.requestFullscreen();
            
            // Fallback for iOS which doesn't support programmatic fullscreen
            if (isIOS) {
                const videoElement = player.el().querySelector('video');
                if (videoElement && videoElement.webkitEnterFullscreen) {
                    videoElement.webkitEnterFullscreen();
                }
            }
        }
    });

    // Volume slider functionality with improved mobile handling
    volumeSlider.addEventListener('input', function() {
        const volumeLevel = this.value / 100;
        player.volume(volumeLevel);
        volumeValue.textContent = `${this.value}%`;
        
        // Mute/unmute based on volume level
        if (volumeLevel === 0) {
            player.muted(true);
        } else if (player.muted()) {
            player.muted(false);
        }
        
        updateButtonStates();
    });

    // Capture preview functionality with improved error handling and feedback
    capturePreviewBtn.addEventListener('click', function() {
        try {
            // Disable button during capture to prevent multiple clicks
            capturePreviewBtn.disabled = true;
            capturePreviewBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Capturing...';
            
            // Create a canvas element
            const canvas = document.createElement('canvas');
            const video = player.tech().el();
            
            // Make sure video is actually playing and has dimensions
            if (video.videoWidth === 0 || video.videoHeight === 0) {
                throw new Error('Video dimensions not available. Make sure the video is playing.');
            }
            
            // Set canvas dimensions to match the video
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            
            // Draw the current video frame on the canvas
            const ctx = canvas.getContext('2d');
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            
            // Convert the canvas to a data URL (PNG image)
            const dataURL = canvas.toDataURL('image/png');
            
            // Update the preview image
            previewImage.src = dataURL;
            previewImage.classList.remove('d-none');
            noPreview.classList.add('d-none');
            
            // Add download capability
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            previewImage.setAttribute('data-filename', `hwo-security-preview-${timestamp}.png`);
            
            // Add click handler for preview to enable download on mobile
            previewImage.onclick = function() {
                // Create a download link
                const link = document.createElement('a');
                link.href = dataURL;
                link.download = previewImage.getAttribute('data-filename');
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            };
            
            // Add download hint for mobile users
            if (isMobile) {
                const downloadHint = document.createElement('p');
                downloadHint.className = 'text-info small mt-2';
                downloadHint.innerHTML = '<i class="fas fa-info-circle me-1"></i> Tap the image to download';
                previewImage.parentNode.appendChild(downloadHint);
            }
            
        } catch (e) {
            console.error('Error capturing preview:', e);
            
            // Show error message
            const errorMsg = document.createElement('div');
            errorMsg.className = 'alert alert-danger mt-3';
            errorMsg.innerHTML = `
                <i class="fas fa-exclamation-triangle me-2"></i>
                Could not capture preview: ${e.message || 'Unknown error'}. 
                Make sure the video is playing and not protected by content security policies.
            `;
            
            const previewContainer = document.getElementById('preview-container');
            previewContainer.appendChild(errorMsg);
            
            // Remove error after 5 seconds
            setTimeout(() => {
                if (errorMsg.parentNode) {
                    errorMsg.parentNode.removeChild(errorMsg);
                }
            }, 5000);
        } finally {
            // Re-enable button
            capturePreviewBtn.disabled = false;
            capturePreviewBtn.innerHTML = '<i class="fas fa-camera me-1"></i> Capture Preview';
        }
    });

    // Update time display with more accurate timekeeping
    player.on('timeupdate', function() {
        currentTimeEl.textContent = formatTime(player.currentTime());
    });
    
    player.on('durationchange', function() {
        if (player.duration() !== Infinity) {
            durationEl.textContent = formatTime(player.duration());
        } else {
            durationEl.textContent = 'Live Stream';
        }
    });

    // Update UI when play state changes
    player.on('play', updateButtonStates);
    player.on('pause', updateButtonStates);
    player.on('volumechange', updateButtonStates);

    // Format time helper function (convert seconds to MM:SS format)
    function formatTime(seconds) {
        if (isNaN(seconds) || seconds === Infinity) return '0:00';
        
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = Math.floor(seconds % 60);
        return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
    }

    // Optimizations for mobile devices
    if (isMobile) {
        // Add mobile device class for CSS targeting
        document.body.classList.add('mobile-device');
        
        // Enable low-latency mode for better mobile performance
        if (player.liveTracker) {
            player.liveTracker.trackingThreshold = 0.5;
        }
        
        // Adjust buffer size for mobile - smaller to save data
        if (player.tech_.hls) {
            player.tech_.hls.bandwidth = 2000000; // Lower bandwidth assumption
            player.tech_.hls.bufferSize = 15; // Smaller buffer (seconds)
        }
        
        // Add touch optimization for controls
        if (isAndroid) {
            // Attempt to force hardware acceleration on Android
            const videoElement = player.el().querySelector('video');
            if (videoElement) {
                videoElement.style.transform = 'translateZ(0)';
            }
        }
    }

    // Handle visibility changes (pause video when tab is not visible)
    document.addEventListener('visibilitychange', function() {
        if (document.hidden && !isMobile) {
            // On mobile, background playback might be desirable, so only pause on desktop
            player.pause();
        }
    });

    // Cleanup on page unload to prevent memory leaks
    window.addEventListener('beforeunload', function() {
        player.dispose();
    });

    // Log player ready and device information
    player.ready(function() {
        console.log('Player is ready');
        
        // Check if HLS is supported natively or via JavaScript
        const hlsSourceExists = player.canPlayType('application/vnd.apple.mpegurl');
        const usingHlsJs = player.tech_.hls !== undefined;
        
        console.log('Native HLS support:', hlsSourceExists ? 'Yes' : 'No');
        console.log('Using HLS.js:', usingHlsJs ? 'Yes' : 'No');
        console.log('Device type:', isMobile ? 'Mobile' : 'Desktop');
        
        // Set initial button states
        updateButtonStates();
    });
    
    // Handle potential playback issues specific to HLS streams
    let stallCount = 0;
    
    player.on('waiting', function() {
        stallCount++;
        if (stallCount > 3) {
            console.warn('Multiple playback stalls detected, attempting to recover...');
            
            // Force player to load a lower quality version if available
            if (player.tech_.hls && player.tech_.hls.representations) {
                const representations = player.tech_.hls.representations();
                if (representations.length > 1) {
                    // Select a lower quality representation
                    for (let i = 0; i < representations.length; i++) {
                        if (i < representations.length - 1) {
                            representations[i].enabled(false);
                        } else {
                            representations[i].enabled(true);
                        }
                    }
                    console.log('Switched to lower quality stream to recover from stalls');
                }
            }
            
            // Reset the stall counter after attempting recovery
            stallCount = 0;
        }
    });
    
    // Reset stall counter on successful playback
    player.on('playing', function() {
        stallCount = 0;
    });
    
    // Copy embed code functionality
    const copyEmbedBtn = document.querySelector('.copy-embed-code');
    if (copyEmbedBtn) {
        copyEmbedBtn.addEventListener('click', function() {
            const embedCode = document.querySelector('code').innerText;
            navigator.clipboard.writeText(embedCode).then(function() {
                const btn = document.querySelector('.copy-embed-code');
                btn.innerHTML = '<i class="fas fa-check me-1"></i> Copied!';
                btn.classList.replace('btn-info', 'btn-success');
                setTimeout(function() {
                    btn.innerHTML = '<i class="fas fa-copy me-1"></i> Copy Embed Code';
                    btn.classList.replace('btn-success', 'btn-info');
                }, 2000);
            });
        });
    }
});
